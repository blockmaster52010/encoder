import os



Symbols = {"0": "00",
           "1": "01",
           "2": "02",
           "3": "03",
           "4": "04",
           "5": "05",
           "6": "06",
           "7": "07",
           "8": "08",
           "9": "09",
           "a": "0A",
           "b": "0B",
           "c": "0C",
           "d": "0D",
           "e": "0E",
           "f": "0F",
           "g": "10",
           "h": "11",
           "i": "12",
           "j": "13",
           "k": "14",
           "l": "15",
           "m": "16",
           "n": "17",
           "o": "18",
           "p": "19",
           "q": "1A",
           "r": "1B",
           "s": "1C",
           "t": "1D",
           "u": "1E",
           "v": "1F",
           "w": "20",
           "x": "21",
           "y": "22",
           "z": "23",
           "A": "24",
           "B": "25",
           "C": "26",
           "D": "27",
           "E": "28",
           "F": "29",
           "G": "2A",
           "H": "2B",
           "I": "2C",
           "J": "2D",
           "K": "2E",
           "L": "2F",
           "M": "30",
           "N": "31",
           "O": "32",
           "P": "33",
           "Q": "34",
           "R": "35",
           "S": "36",
           "T": "37",
           "U": "38",
           "V": "39",
           "W": "3A",
           "X": "3B",
           "Y": "3C",
           "Z": "3D",
           "!": "3E",
           "@": "3F",
           "#": "40",
           "$": "41",
           "%": "42",
           "^": "43",
           "&": "44",
           "*": "45",
           "(": "46",
           ")": "47",
           "`": "48",
           "~": "49",
           "*": "4A",
           "_": "4B",
           "=": "4C",
           "+": "4D",
           "[": "4E",
           "]": "4F",
           "{": "50",
           "}": "51",
           ",": "52",
           ".": "53",
           "<": "54",
           ">": "55",
           "/": "56",
           "\\": "57",
           "?": "58",
           "|": "59",
           ":": "5A",
           ";": "5B",
           "'": "5C",
           '"': "5D",
           " ": "5E"}
rSymbols = {}

filelist = []

continueP = 1

for k, v in Symbols.items():
    rSymbols.update({v: k})


while continueP == 1:
    mux = int(input("\n Enter 1 to encode a file, enter 2 to decode a file, and enter 3 to see a list of existing files: "))

    directory =  os.listdir("C:\\Users\\block\\Downloads\\Python")
    directory2 = []

    for k in directory:
        if k.endswith(".txt"):
            directory2.append(k)
        


    while mux != 1 and mux != 2 and mux != 3:
        mux = int(input("\n input must be 1, 2, or 3: "))


    encoding = ""
    encoded = "" 
    decoding = ""
    decoded = ""
    reading = 1


    if mux == 1:
        
        text = input("\n put in text: ")

        filename = input("\n Name you will save file as: ")
        
        while os.path.exists(filename + ".txt"):
            filename = input("\n File already exists: ")
            


        for k in text:
            encoding = Symbols[k]
            encoded = (encoded + encoding)
                
        with open(filename + ".txt", "w") as f:
            f.write(encoded)
            print(encoded)
    elif mux == 2:
        filename = input("\n Name of file you are reading: ")

        while os.path.exists(filename + ".txt") == False:
            filename = input("\n File does not exist: ")

        with open(filename + ".txt", "r") as f:
            contents = f.read()
            print(contents)
            
            for k in contents:
                if reading == 1:
                    decoding = k
                    reading = 2
                elif reading == 2:
                    decoding += k
                    reading = 1
                    decoded += rSymbols.get(decoding, decoding)

        print(decoded)       

    elif mux == 3:
        for k in directory2:
            print(k)
            

    continueP = int(input("\n Enter 1 to continue using program or enter 2 to end program: "))